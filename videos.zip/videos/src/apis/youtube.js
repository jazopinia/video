import axios from 'axios';

export default axios.create({
    basURL: 'https://www.googleapis.com/youtube/v3',

});

