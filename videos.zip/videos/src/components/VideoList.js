import React from 'react';

const VideoList = ({ videos }) => {
    // props.videos
    return <div>{videos.length}</div>;
}

export default VideoList;